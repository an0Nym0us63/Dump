# -*- coding: latin-1 -*-
# XBMC-Jeedom-EVENT - Service

# IMPORT LIBRARIES
import sys
import os
import subprocess
import xbmc
import xbmcgui
import xbmcaddon
import socket
import urllib2

def linknx_send(ip,jeedombox,api_key,type,id,value):
	try:

		#ex mini 	: http://192.168.0.22/core/api/jeeApi.php?api=ut3c2356f9briua737lj&type=xbmc&id=849&value=Sabotage
		#ex cubie 	: http://192.168.0.23/jeedom/core/api/jeeApi.php?api=ut3c2356f9briua737lj&type=xbmc&id=849&value=Sabotage
		if jeedombox in ["0","2"]:
			req = "http://" + ip + "/core/api/jeeApi.php?api=" + api_key + "&type=" + type + "&id=" + id + "&value=" + value.encode("utf-8")
		else:
			req = "http://" + ip + "/jeedom/core/api/jeeApi.php?api=" + api_key + "&type=" + type + "&id=" + id + "&value=" + value.encode("utf-8")
		
		switch_log('XBMC-Jeedom-EVENT: linKNX connecting to ' + req)
		urllib2.urlopen(req)
		
	except Exception, err:
		xbmc.log('XBMC-Jeedom-EVENT: linKNX connection failed',xbmc.LOGWARNING)

def switch_log(message):	
	xbmc.log(message)
		
# ADDON INFORMATION
__addon__     = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__cwd__       = __addon__.getAddonInfo('path')
__author__    = __addon__.getAddonInfo('author')
__version__   = __addon__.getAddonInfo('version')
__dbg__ = __addon__.getSetting('debug_mod')	
		
xbmc.log('XBMC-Jeedom-EVENT: Addon information')
xbmc.log('XBMC-Jeedom-EVENT: ----> Addon name    : ' + __addonname__)
xbmc.log('XBMC-Jeedom-EVENT: ----> Addon path    : ' + __cwd__)
xbmc.log('XBMC-Jeedom-EVENT: ----> Addon author  : ' + __author__ )
xbmc.log('XBMC-Jeedom-EVENT: ----> Addon version : ' + __version__)

# ADDON LINKNX SERVER SETTINGS
my_ip = __addon__.getSetting("ip")
my_jeedombox = __addon__.getSetting("jeedombox")
my_api_key = __addon__.getSetting("api_key")
my_virtuel_id1 = __addon__.getSetting("virtuel_id1")
my_virtuel_id2 = __addon__.getSetting("virtuel_id2")
my_virtuel_id3 = __addon__.getSetting("virtuel_id3")
switch_log('XBMC-Jeedom-EVENT: Addon Host settings')
switch_log('XBMC-Jeedom-EVENT: IP number            : ' + my_ip)
switch_log('XBMC-Jeedom-EVENT: JeedomBox            : ' + my_jeedombox)
switch_log('XBMC-Jeedom-EVENT: APIKey               : ' + my_api_key)
switch_log('XBMC-Jeedom-EVENT: virtuel_id1          : ' + my_virtuel_id1)
switch_log('XBMC-Jeedom-EVENT: virtuel_id2          : ' + my_virtuel_id2)
switch_log('XBMC-Jeedom-EVENT: virtuel_id3          : ' + my_virtuel_id3)

# ADDON START
xbmc.log('XBMC-Jeedom-EVENT: STARTUP')
#START Initialisation cycle
#Make sure Device is on
#Get the state of le ligth
#END Initialisation cycle

switch_log('XBMC-Jeedom-EVENT: START EVENT')

# ADDON PLAYER
switch_log('XBMC-Jeedom-EVENT: NEW CLASS PLAYER')

def Jeedom(str_id,value):

	my_ip = __addon__.getSetting("ip")
	my_jeedombox = __addon__.getSetting("jeedombox")
	my_api_key = __addon__.getSetting("api_key")
	my_type = "xbmc"
	my_id = 0
	if str_id == "title" :
		my_id =  __addon__.getSetting("virtuel_id1")
	elif str_id == "status" :
		my_id =  __addon__.getSetting("virtuel_id2")
	elif str_id == "status_id" :
		my_id =  __addon__.getSetting("virtuel_id3")
	
	my_value = value
	
	linknx_send(my_ip,my_jeedombox,my_api_key,my_type,my_id,my_value)
	
	switch_log('########### ENVOI VERS JEEDOM ###########')
	switch_log(str(id))
	switch_log(value.encode('utf-8'))
	switch_log('######### FIN ENVOI VERS JEEDOM #########')
		

class MyPlayer(xbmc.Player):
	def __init__ (self):
		xbmc.Player.__init__(self)
		switch_log('XBMC-Jeedom-EVENT: Class player is initialized')
		if (str(__addon__.getSetting("xbmc_started")) == "Oui"):
			Jeedom('title',u'Aucun')
			Jeedom('status',u"D�marr�")
			Jeedom('status_id',u'0')

	def onPlayBackStarted(self):
		xbmc.sleep(200) # it may take some time for xbmc to read tag info after playback started
		if xbmc.Player().isPlayingVideo():
			if (str(__addon__.getSetting("video_started")) == "Oui"):
				Jeedom('status',u"Vid�o en cours")
				Jeedom('status_id',u'1')	
				if (str(__addon__.getSetting("video_title")) == "Oui"):
					if xbmc.getInfoLabel("VideoPlayer.TVShowTitle"):
						epi=xbmc.getInfoLabel("VideoPlayer.Episode")
						sais=xbmc.getInfoLabel("VideoPlayer.Season")
						if len(epi)<2:
							epi='0'+epi
						if len(sais)<2:
							sais='0'+sais
						title= xbmc.getInfoLabel("VideoPlayer.TVShowTitle") +' : S'+  sais +'E'+ epi+' - '+xbmc.getInfoLabel("VideoPlayer.Title") 
					else:
						title = xbmc.getInfoLabel("VideoPlayer.Title")
					Jeedom('title',title.decode("utf-8"))
					
		if xbmc.Player().isPlayingAudio() == True:
			if (str(__addon__.getSetting("audio_started")) == "Oui"):
				Jeedom('status',u"Audio en cours")
				Jeedom('status_id',u'2')
				if (str(__addon__.getSetting("audio_title")) == "Oui"):
					title = xbmc.getInfoLabel("MusicPlayer.Artist") + " - " + xbmc.getInfoLabel("MusicPlayer.Title")
					Jeedom('title',title.decode("utf-8"))

	def onPlayBackEnded(self):		
		if (VIDEO == 1):
			if (str(__addon__.getSetting("video_ended")) == "Oui"):
				Jeedom('title',u'Aucun')
				Jeedom('status',u"Video termin�e")
				Jeedom('status_id',u'3')
		if (AUDIO == 1):
			if (str(__addon__.getSetting("audio_ended")) == "Oui"):
				Jeedom('title',u'Aucun')
				Jeedom('status',u"Audio termin�e")
				Jeedom('status_id',u'4')
					  
	def onPlayBackStopped(self):                                                                                                                         
		if (VIDEO == 1):
			if (str(__addon__.getSetting("video_stopped")) == "Oui"):
				Jeedom('title',u'Aucun')
				Jeedom('status',u"Vid�o arr�t�e")
				Jeedom('status_id',u'5')
				
		if (AUDIO == 1):
			if (str(__addon__.getSetting("audio_stopped")) == "Oui"):
				Jeedom('title',u'Aucun')
				Jeedom('status',u"Audio arr�t�e")
				Jeedom('status_id',u'6')

	def onPlayBackPaused(self):
		if xbmc.Player().isPlayingVideo():
			if (str(__addon__.getSetting("video_paused")) == "Oui"):
				Jeedom('status',u"Vid�o en pause")
				Jeedom('status_id',u'7')
	
		if xbmc.Player().isPlayingAudio():
			if (str(__addon__.getSetting("audio_paused")) == "Oui"):
				Jeedom('status',u"Audio en pause")
				Jeedom('status_id',u'8')
							
	def onPlayBackResumed(self):
		if xbmc.Player().isPlayingVideo():                                                                                                           
			if (str(__addon__.getSetting("video_resumed")) == "Oui"):
				Jeedom('status',u"Reprise vid�o")
				Jeedom('status_id',u'9')
				
		if xbmc.Player().isPlayingAudio():
			if (str(__addon__.getSetting("audio_resumed")) == "Oui"):
				Jeedom('status',u"Reprise audio")
				Jeedom('status_id',u'10')
								   
##So this is where we really start the plugin.
argc = len(sys.argv)
switch_log( "Jeedom -> Script argument is " + str(sys.argv))

try:
    params=get_params(sys.argv[2])
except:
    params={}
	
if argc == 1:
	player=MyPlayer()
	while(not xbmc.abortRequested):
		if xbmc.Player().isPlayingVideo():
			VIDEO = 1
			AUDIO = 0
		else:
			VIDEO = 0
			AUDIO = 1

		xbmc.sleep(300)

	if str(__addon__.getSetting("xbmc_ended")) == "Oui":
		Jeedom('title',u'Aucun')
		Jeedom('status',u"Arr�t")
		Jeedom('status_id',u'18')
else:
	switch_log( "Jeedom -> Script a traiter")
	
